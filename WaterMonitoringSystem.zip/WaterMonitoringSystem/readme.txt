Use application url as http://localhost:8080/WaterMonitoringSystem/

REST API for getting all water data

http://localhost:8080/WaterMonitoringSystem/rest/water/datas

Get Jersey REST APIS jars from 
https://jersey.github.io/download.html

Using ChartJs for showing graphical representation of data. More details can be found at
http://www.chartjs.org/