package edu.pune.university.exception;

public class ApplicationException extends Throwable {

	private static final long serialVersionUID = 1L;

}
